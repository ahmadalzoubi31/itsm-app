// src/app/(core)/iam/users/[id]/page.tsx
import { notFound } from "next/navigation";
import UserForm from "../../components/user-form";
import { getUserServer } from "../../services/user.server";

interface EditUserPageProps {
  params: { id: string };
}

const Page = async ({ params }: EditUserPageProps) => {
  const { id } = params;

  // Server-side fetch (cookies are forwarded automatically)
  const user = await getUserServer(id);

  if (!user) {
    notFound();
  }

  return (
    <>
      <div className="flex flex-row items-center justify-between px-4 lg:px-8">
        <div className="text-2xl font-bold tracking-tight">
          Edit User
          <div className="text-muted-foreground text-sm font-normal">
            Modify user details, roles, and permissions
          </div>
        </div>
      </div>

      <div className="px-4 lg:px-8">
        {/* 👇 pass the loaded user as initialData */}
        <UserForm id={id} initialData={user} />
      </div>
    </>
  );
};

export default Page;
