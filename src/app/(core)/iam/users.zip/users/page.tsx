import { use } from "react";
import { listUsersServer } from "./services/user.server";
import UsersPageClient from "./components/users-page-client";

const Page = () => {
  // HOOKS
  // Custom Hooks

  // React Hooks
  const usersPromise = listUsersServer();
  const users = use(usersPromise);

  // EFFECTS

  // HELPERS

  // EVENT HANDLERS

  // EARLY RETURNS

  // RENDER LOGIC

  return <UsersPageClient initialUsers={users} />;
};

export default Page;
