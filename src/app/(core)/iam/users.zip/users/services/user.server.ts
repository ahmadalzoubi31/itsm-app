import { cookies } from "next/headers";
import { fetchWithAuth } from "@/utils/fetchWithAuth";
import { getBackendUrl } from "@/utils/getBackendUrl";
import { AUTH_ENDPOINTS } from "@/constants/api-endpoints";
import { USERS_ENDPOINTS } from "@/constants/api-endpoints/users.endpoints";
import { User } from "../interfaces";

// Get logged-in user (SSR-safe)
export async function getLoggedUser(): Promise<User | null> {
  const cookieStore = await cookies();
  const cookieHeader = cookieStore
    .getAll()
    .map((c) => `${c.name}=${c.value}`)
    .join("; ");

  const url = getBackendUrl(AUTH_ENDPOINTS.me);
  const res = await fetchWithAuth(url, {});
  const data = await res.json();
  return data as User;
}

// Get all users (Server-side)
export async function listUsersServer(): Promise<User[]> {
  try {
    const cookieStore = await cookies();
    const cookieHeader = cookieStore
      .getAll()
      .map((cookie) => `${cookie.name}=${cookie.value}`)
      .join("; ");

    const response = await fetch(getBackendUrl(USERS_ENDPOINTS.base), {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        Cookie: cookieHeader,
      },
      cache: "no-store",
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch users: ${response.statusText}`);
    }

    const data = await response.json();
    return data as User[];
  } catch (error) {
    console.error("Error fetching users:", error);
    throw error;
  }
}

// Get user by ID (Server-side)
export async function getUserServer(id: string): Promise<User | null> {
  try {
    const cookieStore = await cookies();
    const cookieHeader = cookieStore
      .getAll()
      .map((cookie) => `${cookie.name}=${cookie.value}`)
      .join("; ");

    const response = await fetch(getBackendUrl(USERS_ENDPOINTS.byId(id)), {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        Cookie: cookieHeader,
      },
      cache: "no-store",
    });

    if (!response.ok) {
      if (response.status === 404) {
        return null;
      }
      throw new Error(`Failed to fetch user: ${response.statusText}`);
    }

    const data = await response.json();
    return data as User;
  } catch (error) {
    console.error("Error fetching user:", error);
    throw error;
  }
}
