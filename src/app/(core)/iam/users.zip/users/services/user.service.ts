import { fetchWithAuth } from "@/utils/fetchWithAuth";
import { getBackendUrl } from "@/utils/getBackendUrl";
import { USERS_ENDPOINTS } from "@/constants/api-endpoints/users.endpoints";
import { User, CreateUserDto, UpdateUserDto } from "../interfaces";

// CRUD operations for users
// Create new user
export async function createUser(dto: CreateUserDto): Promise<User> {
  return await fetchWithAuth(getBackendUrl(USERS_ENDPOINTS.base), {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(dto),
  });
}

// Get all users
export async function listUsers(): Promise<User[]> {
  return await fetchWithAuth(getBackendUrl(USERS_ENDPOINTS.base), {
    headers: { "Content-Type": "application/json" },
  });
}

// Get user by ID
export async function getUser(id: string): Promise<User> {
  return await fetchWithAuth(getBackendUrl(USERS_ENDPOINTS.byId(id)), {
    headers: { "Content-Type": "application/json" },
  });
}

// Update user
export async function updateUser(
  id: string,
  dto: UpdateUserDto
): Promise<User> {
  return await fetchWithAuth(getBackendUrl(USERS_ENDPOINTS.byId(id)), {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(dto),
  });
}
// Delete user
export async function deleteUser(
  id: string
): Promise<{ id: string; deleted: boolean }> {
  return await fetchWithAuth(getBackendUrl(USERS_ENDPOINTS.byId(id)), {
    method: "DELETE",
    headers: { "Content-Type": "application/json" },
  });
}
