"use client";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { User, Mail, Lock, Info } from "lucide-react";
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { UseFormReturn } from "react-hook-form";
import { Separator } from "@/components/ui/separator";
import { AuthSource } from "../interfaces";
import { Badge } from "@/components/ui/badge";

interface UserBasicInfoProps {
  form: UseFormReturn<any>;
}

const UserBasicInfo = ({ form }: UserBasicInfoProps) => {
  // HOOKS
  // Custom Hooks

  // React Hooks

  // EFFECTS

  // HELPERS

  // EVENT HANDLERS

  // EARLY RETURNS

  // RENDER LOGIC

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <User className="h-5 w-5" />
          Personal Information
        </CardTitle>
        <CardDescription>
          Enter the user's personal details and contact information
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <Separator />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
          <FormField
            control={form.control}
            name="username"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Username</FormLabel>
                <FormControl>
                  <Input
                    placeholder="jdoe"
                    autoComplete="username"
                    maxLength={80}
                    {...field}
                  />
                </FormControl>

                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="displayName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Display Name</FormLabel>
                <FormControl>
                  <Input placeholder="John Doe" maxLength={150} {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>
                  <Mail className="h-4 w-4 inline" /> Email Address (Optional)
                </FormLabel>
                <FormControl>
                  <Input
                    placeholder="john.doe@company.com"
                    maxLength={150}
                    {...field}
                    value={field.value ?? ""}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormItem>
            <FormLabel className="flex items-center gap-2">
              Authentication Source
              <Info className="h-3 w-3 text-muted-foreground" />
            </FormLabel>
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="text-sm">
                {form.watch("authSource") === AuthSource.LDAP
                  ? "LDAP"
                  : "Local"}
              </Badge>
              <span className="text-xs text-muted-foreground">
                {form.watch("authSource") === AuthSource.LDAP
                  ? "Set automatically for LDAP users"
                  : "Set automatically for manually created users"}
              </span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              This field is automatically determined by the system
            </p>
          </FormItem>
        </div>

        {/* Show password field for new users (manual creation = local) or existing local users */}
        {(form.watch("authSource") === AuthSource.LOCAL ||
          !form.watch("authSource")) && (
          <FormField
            control={form.control}
            name="password"
            render={({ field }) => (
              <FormItem>
                <FormLabel>
                  <Lock className="h-4 w-4 inline" /> Password
                </FormLabel>
                <FormControl>
                  <Input
                    type="password"
                    placeholder="SecurePass123!"
                    autoComplete="new-password"
                    {...field}
                  />
                </FormControl>
                <p className="text-sm text-muted-foreground">
                  Must be at least 8 characters with uppercase, lowercase, and
                  number/special character
                </p>
                <FormMessage />
              </FormItem>
            )}
          />
        )}

        <FormField
          control={form.control}
          name="externalId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>External ID (Optional)</FormLabel>
              <FormControl>
                <Input
                  placeholder="AD GUID (for LDAP users)"
                  {...field}
                  value={field.value ?? ""}
                />
              </FormControl>
              <p className="text-sm text-muted-foreground">
                External identifier for LDAP users
              </p>
              <FormMessage />
            </FormItem>
          )}
        />
      </CardContent>
    </Card>
  );
};

export default UserBasicInfo;
