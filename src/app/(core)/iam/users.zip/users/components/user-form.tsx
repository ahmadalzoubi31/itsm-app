"use client";

import z from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { User, Shield, Settings, UserCog } from "lucide-react";
import { FieldErrors, useForm } from "react-hook-form";
import { toast } from "sonner";
import { upsertUserAction } from "../actions";
import { userSchema } from "../validations";
import SideBarForm from "./side-bar-form";
import UserBasicInfo from "./user-basic-info-tab";
import UserPermissions from "./user-permission-tab";
import UserSettings from "./user-settings-tab";
import UserRoles from "./user-role-tab";
import { Skeleton } from "@/components/ui/skeleton";
import { CreateUserDto } from "../interfaces";
import { Form } from "@/components/ui/form";

type UserFormValues = z.infer<typeof userSchema>;

type UserFormProps = {
  id?: string;
  initialData?: any; // ideally your User type from the backend
};

const UserForm = ({ id, initialData }: UserFormProps) => {
  const form = useForm<UserFormValues>({
    resolver: zodResolver(userSchema),
    defaultValues: {
      username: "",
      email: "",
      displayName: "",
      authSource: "local",
      externalId: "",
      password: "",
      isActive: true,
      isLicensed: false,
      permissions: [],
      roles: [],
      // 👇 hydrate from server data on first render
      ...(initialData && {
        username: initialData.username ?? "",
        email: initialData.email ?? "",
        displayName: initialData.displayName ?? "",
        authSource: initialData.authSource,
        externalId: initialData.externalId ?? "",
        // usually you don’t send password back, but you had it in your example
        isActive: initialData.isActive,
        isLicensed: initialData.isLicensed,
        permissions: initialData.permissions ?? [],
        roles: initialData.roles ?? [],
      }),
    },
  });

  // HELPERS

  // EVENT HANDLERS
  const onSubmit = async (data: UserFormValues) => {
    const promise = async () => {
      // Just call the server action – it will handle create/update/relations
      await upsertUserAction(data);
    };

    toast.promise(promise, {
      loading: id ? "Updating user..." : "Creating user...",
      success: id ? "User updated successfully" : "User created successfully",
      error: "Something went wrong while saving the user.",
    });
  };

  // EARLY RETURNS
  if (form.formState.isSubmitting) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 space-y-6">
          {/* Tabs skeleton */}
          <div className="flex gap-4 mb-4">
            <Skeleton className="h-10 w-32 rounded-lg" />
            <Skeleton className="h-10 w-32 rounded-lg" />
            <Skeleton className="h-10 w-32 rounded-lg" />
          </div>
          {/* Basic Info fields */}
          <Skeleton className="h-16 w-full rounded-xl" />
          <Skeleton className="h-40 w-full rounded-xl" />
          {/* Permissions tab skeleton */}
          <Skeleton className="h-20 w-full rounded-xl" />
          {/* Settings tab skeleton */}
          <Skeleton className="h-24 w-full rounded-xl" />
        </div>
        {/* Sidebar skeleton */}
        <div className="space-y-6">
          <Skeleton className="h-72 w-full rounded-xl" />
        </div>
      </div>
    );
  }

  // RENDER LOGIC
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-3 space-y-6">
            <Tabs defaultValue="basic" className="w-full">
              <TabsList
                className={`grid w-full ${
                  form.getValues("isLicensed") ? "grid-cols-4" : "grid-cols-2"
                }`}
              >
                <TabsTrigger value="basic" className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Basic Info
                </TabsTrigger>
                {form.getValues("isLicensed") && (
                  <TabsTrigger
                    value="roles"
                    className="flex items-center gap-2"
                  >
                    <UserCog className="h-4 w-4" />
                    Roles
                  </TabsTrigger>
                )}
                {form.getValues("isLicensed") && (
                  <TabsTrigger
                    value="permissions"
                    className="flex items-center gap-2"
                  >
                    <Shield className="h-4 w-4" />
                    Permissions
                  </TabsTrigger>
                )}
                <TabsTrigger
                  value="settings"
                  className="flex items-center gap-2"
                >
                  <Settings className="h-4 w-4" />
                  Settings
                </TabsTrigger>
              </TabsList>

              {/* Basic Information Tab */}
              <TabsContent value="basic" className="space-y-6">
                <UserBasicInfo form={form} />
              </TabsContent>

              {/* Roles Tab */}
              {form.getValues("isLicensed") && (
                <TabsContent value="roles">
                  <UserRoles form={form} />
                </TabsContent>
              )}

              {/* Permissions Tab */}
              {form.getValues("isLicensed") && (
                <TabsContent value="permissions">
                  <UserPermissions form={form} />
                </TabsContent>
              )}

              {/* Settings Tab */}
              <TabsContent value="settings">
                <UserSettings form={form} />
              </TabsContent>
            </Tabs>
          </div>
          <SideBarForm
            form={form}
            errors={form.formState.errors as FieldErrors<CreateUserDto>}
          />
        </div>
      </form>
    </Form>
  );
};

export default UserForm;
