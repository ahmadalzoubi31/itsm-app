"use client";
import SectionCards from "./section-cards";
import { columns } from "./columns";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { PlusIcon } from "lucide-react";
import { DataTable } from "@/components/data-table";
import { tableConfig } from "./table-config";
import { User } from "../interfaces";
import { useMemo } from "react";

interface UsersPageClientProps {
  initialUsers: User[];
}

const UsersPageClient = ({ initialUsers }: UsersPageClientProps) => {
  // HOOKS
  // Custom Hooks

  // React Hooks
  const { totalUsers, newUsers, manualUsers, importedUsers, agentUsers } =
    useMemo(() => {
      const totalUsers = initialUsers.length;

      const today = new Date();

      const newUsers = initialUsers.filter((user: User) => {
        const userDate = new Date(user.createdAt);
        const diffDays =
          (today.getTime() - userDate.getTime()) / (1000 * 60 * 60 * 24);
        return diffDays <= 30;
      });

      // Manual users are local auth users (no externalId)
      const manualUsers = initialUsers.filter(
        (user: User) => user.authSource === "local" && !user.externalId
      );

      // Imported users are LDAP users (have externalId)
      const importedUsers = initialUsers.filter(
        (user: User) => user.authSource === "ldap" && user.externalId
      );

      // Check for agent role in userRoles relation
      const agentUsers = initialUsers.filter((user: User) => {
        const roles = user.roles || [];
        return roles.some((r) => r.key === "agent");
      });

      return {
        totalUsers,
        newUsers,
        manualUsers,
        importedUsers,
        agentUsers,
      };
    }, [initialUsers]);

  // EFFECTS

  // HELPERS

  // EVENT HANDLERS

  // EARLY RETURNS

  // RENDER LOGIC

  return (
    <>
      <div className="flex flex-row items-center justify-between px-4 lg:px-8">
        <div className="text-2xl font-bold tracking-tight">
          Users
          <div className="text-muted-foreground text-sm font-normal">
            Filter and manage your assigned users
          </div>
        </div>
        <Button size="sm" asChild>
          <Link
            href="/iam/users/new"
            className="dark:text-foreground flex items-center gap-2"
          >
            <PlusIcon className="size-4" />
            Create User
          </Link>
        </Button>
      </div>

      <div className="px-4 lg:px-8">
        <SectionCards
          totalUsers={totalUsers}
          totalNewUsers={newUsers.length}
          totalManualUsers={manualUsers.length}
          totalImportedUsers={importedUsers.length}
          totalAgentUsers={agentUsers.length}
        />
      </div>
      <div className="px-4 lg:px-8">
        <DataTable
          data={initialUsers}
          columns={columns}
          isLoading={false}
          config={tableConfig}
          refetch={async () => {
            return Promise.resolve();
          }}
        />
      </div>
    </>
  );
};

export default UsersPageClient;
