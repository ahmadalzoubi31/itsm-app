"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { UserFormValues, userSchema } from "./validations/user.schema";
import { createUser, updateUser, deleteUser } from "./services/user.service";
import { assignPermissionsToUser } from "../permissions/services/permission.service";
import { assignRolesToUser } from "../roles/services/role.service";
// if you have these helpers from other features:

// Helper: validate payload again on the server (never trust client only)
function validateUserOnServer(data: UserFormValues) {
  const result = userSchema.safeParse(data);
  if (!result.success) {
    // You can shape this however you like for error handling
    throw new Error("Server validation failed");
  }
  return result.data;
}

// CREATE or UPDATE (upsert) user + roles + permissions
export async function upsertUserAction(data: UserFormValues) {
  const valid = validateUserOnServer(data);

  // Extract relations
  const { roles, permissions, id, authSource, externalId, ...userData } = valid;

  if (id) {
    // UPDATE
    await updateUser(id, userData);

    // roles / permissions logic (example, adjust to your real services)
    if (roles) {
      await assignRolesToUser(id, {
        roleIds: roles
          .map((r) => r.id!)
          .filter((id): id is string => id !== undefined),
      });
    }

    if (permissions) {
      await assignPermissionsToUser(id, {
        permissionIds: permissions.map((p) => p.id),
      });
    }
  } else {
    // CREATE
    const newUser = await createUser({
      // your backend CreateUserDto fields
      username: userData.username,
      email: userData.email,
      displayName: userData.displayName,
      isActive: userData.isActive,
      isLicensed: userData.isLicensed,
      password: userData.password,
      authSource: authSource, // if needed
      externalId: externalId,
    });

    if (roles && roles.length > 0) {
      await assignRolesToUser(newUser.id, {
        roleIds: roles
          .map((r) => r.id!)
          .filter((id): id is string => id !== undefined),
      });
    }

    if (permissions && permissions.length > 0) {
      await assignPermissionsToUser(newUser.id, {
        permissionIds: permissions.map((p) => p.id),
      });
    }
  }

  // Make sure the list page gets fresh data
  revalidatePath("/(core)/iam/users");
  redirect("/(core)/iam/users");
}

// DELETE user
export async function deleteUserAction(id: string) {
  await deleteUser(id);

  // You may also want to clean up relations here
  // await unassignRolesFromUser(id);
  // await unassignPermissionsFromUser(id);

  revalidatePath("/(core)/iam/users");
}
