import { useQuery } from "@tanstack/react-query";
import { getUser } from "../services";
import { User } from "../interfaces";

export function useUser(id: string) {
  const { data, error, isLoading, refetch } = useQuery<User>({
    queryKey: ["user", id],
    queryFn: () => getUser(id),
  });

  return {
    user: data,
    error,
    isLoading,
    refetch,
  };
}

